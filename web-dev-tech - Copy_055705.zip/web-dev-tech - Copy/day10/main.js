import { greet } from "./greeting.js";

function main(){
    greet();
}
main();