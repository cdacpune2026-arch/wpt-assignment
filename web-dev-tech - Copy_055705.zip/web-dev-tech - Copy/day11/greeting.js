export async function greet() {
  let timeOfDay = new Date().getHours();
  if (timeOfDay < 12) {
    console.log("Good morning");
  } else if (timeOfDay > 12 && timeOfDay < 16) {
    console.log("Good afternoon");
  } else if (timeOfDay < 18) {
    console.log("Good evening");
  } else {
    console.log("Good night");
  }
}
