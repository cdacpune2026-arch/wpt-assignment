const { greet } = require("./greeting.js");

setTimeout(async function main() {
  await greet();
}, 200);
