const fs = require("fs")

let tableOf3 = [];

for(let i=1; i<=10;i++){
    tableOf3.push(3*i);
}

// fs.writeFileSync("dummy.txt", tableOf3.toString())

fs.writeFile("dummy1.txt", tableOf3.toString(), (err)=> {
    if(err) {
        console.err(err);
        return
    }
    console.log("File written successfully")
})