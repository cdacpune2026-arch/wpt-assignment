const fs = require("fs");

fs.readFile("./dummyinput.txt", (err, data) => {
  if (err) {
    console.error(err.message);
    return;
  }

  console.log("Read from one file");
  fs.writeFile("./dummyoutput.txt", data, (err) => {
    if (err) {
      console.error(err.message);
      return;
    }
    console.log("Written to another file");
  });
});
