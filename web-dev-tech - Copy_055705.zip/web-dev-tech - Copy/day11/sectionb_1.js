export async function sumArr(arr) {
  if (!Array.isArray(arr)) {
    throw new Error("Array is required to calculate sum");
  }

  let sum = 0;
  for (const ele of arr) {
    sum += ele;
  }
  return sum;
}

export function sumArrPromise(arr) {
  return new Promise(function (resolve, reject) {
    if (!Array.isArray(arr)) {
      reject("Array is required to calculate sum");
    }

    let sum = 0;
    for (const ele of arr) {
      sum += ele;
    }
    resolve(sum);
  });
}

// let arr = [1,2,3,4];
// sumArr(arr)
//   .then((val) => console.log("Sum of elements in : ", arr, ":", val))
//   .catch((err) => console.error(err.message));

// sumArrPromise(arr)
//   .then((val) => console.log("Sum of elements in : ", arr, ":", val))
//   .catch((err) => console.error(err));
