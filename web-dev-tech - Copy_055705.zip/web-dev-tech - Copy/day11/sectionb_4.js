const { sumArr, sumArrPromise } = require("./sectionb_1.js");

let arr = [
  [1, 2, 3],
  [3, 4, 5],
  [7, 8, 9],
];

let promises = [];

arr.map((subArr) => promises.push(sumArr(subArr)));

Promise.all(promises).then((values) => {
  values.forEach((val, index) => {
    arr[index] = val;
  });
  console.log(arr);
});
