const express = require("express");

const app = express();

app.use(express.urlencoded());
app.use(express.json());

app.use(express.static("public"));

app.use(
  "/scripts",
  express.static(__dirname + "/node_modules/bootstrap/dist/")
);

app.get("/", (req, res) => {
  res.send("hello world");
});

app.post("/register", (req, res) => {
  const { body } = req;

  res.send("GOT DATA");
});

let port = 8081;
app.listen(port, () => {
  console.log("Server started on port: ", port);
});
