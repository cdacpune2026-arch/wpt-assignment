const fs = require("fs");

const movies = [];

fs.readFile("movies.info", function (err, data) {
  if (err) {
    console.log("ERROR: ", err.message);
    return;
  }

  if (data.length == 0) {
    return;
  }
  Array.from(JSON.parse(data)).forEach((mov) => movies.push(mov));
});

exports.newMovie = function (req, res) {
  const { body } = req;

  const { movieName, moviePrice, movieSeat } = body || {};

  if (String(movieName).length <= 5 || Number.parseFloat(moviePrice) < 0) {
    res.status(500).json({ error: "Invalid fields" });
    return;
  }

  let movie = { movieName, moviePrice, movieSeat }
  movies.push(movie)

  fs.writeFile("movies.info", JSON.stringify(movies), function(err){
    if(err){
        console.log("ERROR: ", err.message)
        return
    }
  })
  res.json({ msg: "success" });
}

exports.getMovies = function (req, res) {
  res.json({ movies });
};