const express = require("express");
const morgan = require("morgan");
const router = require("./routers/movies.js");

const app = express();

app.use(express.urlencoded());
app.use(express.json());
app.use(morgan("short"));

app.use(
  "/scripts",
  express.static(__dirname + "/node_modules/bootstrap/dist/")
);

app.use(express.static("public"));

app.get("/", function (req, res) {
  res.json({ status: "healthy" });
});

app.use("/movies", router);

app.listen("3000", function (err) {
  if (err) {
    console.log(err);
    return;
  }

  console.log("Server started successfully");
});
