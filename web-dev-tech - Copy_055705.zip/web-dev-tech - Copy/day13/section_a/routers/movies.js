const express = require("express")
const router = express.Router();
const movieController = require("../controllers/movieController.js")


router.post("/new", movieController.newMovie)

router.get("/", movieController.getMovies)

module.exports = router;

