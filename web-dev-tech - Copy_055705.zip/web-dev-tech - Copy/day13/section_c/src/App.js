import { Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  const myName = "Shridhar Kulkarni";

  return (
    <div className="heading">
      <Button>
        Hello there {">>>"} {myName}
      </Button>
    </div>
  );
}

export default App;
