const express = require("express")
const morgan = require("morgan");
const router = require("./routers/movies");

const app = express();
app.use(morgan("short"))

app.use(express.urlencoded())
app.use(express.json())

app.use("/movies", router)

app.listen("8081", (err)=>{
    if(err){
        console.error(err)
        return
    }

    console.log("Server started on port : ", 8081)
})