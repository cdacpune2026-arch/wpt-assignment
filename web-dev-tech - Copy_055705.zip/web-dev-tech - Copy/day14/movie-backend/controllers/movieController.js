const movies = [];

exports.addNewMovie = function (req, res) {
  const { body } = req;

  let movie = { ...body };

  movies.push(movie);

  res.json({ msg: "success" });
};

exports.getMovies = function (req, res) {
  res.json({ movies });
};
