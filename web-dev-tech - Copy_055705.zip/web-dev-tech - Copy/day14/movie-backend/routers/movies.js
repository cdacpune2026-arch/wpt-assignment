const express = require("express");
const { addNewMovie, getMovies } = require("../controllers/movieController");
const router = express.Router();


router.post("/new", addNewMovie)

router.get("/", getMovies)

module.exports=router;