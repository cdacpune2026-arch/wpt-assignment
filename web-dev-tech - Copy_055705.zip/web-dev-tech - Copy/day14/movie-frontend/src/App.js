import { useEffect, useState } from "react";
import MovieForm from "./components/MovieForm";
import MovieTable from "./components/MovieTable";
import "bootstrap/dist/css/bootstrap.min.css";

export default function App() {
  const [movies, setMovies] = useState([]);

  const refetch = () => {
    fetch("/movies", {
      method: "GET",
    })
      .then((res) => res.json())
      .then((data) => setMovies(data.movies || []))
      .catch((err) => console.error("Error fetching movies:", err));
  };

  useEffect(() => {
    refetch();
  }, []);

  return (
    <div className="container-xl pt-5">
      <header className="mb-5 pb-3 border-bottom border-dark">
        <h1 className="display-5 fw-bold text-dark mb-1">MovieMan</h1>
        <p className="lead text-muted">Your own movie management interface.</p>
      </header>

      <div className="row">
        <div className="col-lg-4 col-md-5 mb-5">
          <MovieForm refetch={refetch} />
        </div>

        <div className="col-lg-8 col-md-7">
          <MovieTable movies={movies} />
        </div>
      </div>
    </div>
  );
}
