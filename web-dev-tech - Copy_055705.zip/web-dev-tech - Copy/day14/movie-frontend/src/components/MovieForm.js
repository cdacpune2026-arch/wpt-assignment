import { useState } from "react";

export default function MovieForm(props) {
  const [checkBoxes, setCheckBoxes] = useState({
    "2D": true,
    "3D": false,
    IMAX: false,
  });

  const submitMovie = (e) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const selectedMovieTypes = Object.keys(checkBoxes).filter((key) => checkBoxes[key]);

    const movieData = Object.fromEntries(formData.entries());
    movieData.movieType = selectedMovieTypes;

    fetch("/movies/new", {
      method: "POST",
      body: JSON.stringify(movieData),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => res.json())
      .then(() => props.refetch?.())
      .catch((err) => console.error(err.message));
  };
  
  const handleCheckboxChange = (checkName) => {
    setCheckBoxes((prev) => ({
      ...prev,
      [checkName]: !prev[checkName],
    }));
  };

  return (
    <div className="p-4 border rounded-3 bg-light"> {/* Simple border and background */}
      <h4 className="mb-4 text-secondary">Add New Movie</h4>
      <form onSubmit={submitMovie}>
        <div className="mb-3">
          <input
            type="text"
            name="movieName"
            placeholder="Movie name..."
            className="form-control form-control-lg" // Larger inputs
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="actorName"
            placeholder="Actor..."
            className="form-control form-control-lg"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="date"
            name="releaseDate"
            placeholder="Release Date..."
            className="form-control form-control-lg"
            required
          />
        </div>

        <div className="mb-4">
          <label className="form-label d-block text-muted">Movie Type:</label>
          {Object.keys(checkBoxes).map((checkName) => {
            return (
              <div key={checkName} className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id={checkName}
                  name="movieType"
                  checked={checkBoxes[checkName]}
                  onChange={() => handleCheckboxChange(checkName)}
                />
                <label className="form-check-label text-dark" htmlFor={checkName}>
                  {checkName}
                </label>
              </div>
            );
          })}
        </div>

        <button type="submit" className="btn btn-primary btn-lg w-100">
          Add Movie
        </button>
      </form>
    </div>
  );
}