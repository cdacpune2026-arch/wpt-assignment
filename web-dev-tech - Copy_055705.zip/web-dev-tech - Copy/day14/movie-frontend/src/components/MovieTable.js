export default function MovieTable(props) {
  return (
    <div className="table-responsive"> 
      <table
        className="table table-bordered table-hover align-middle" 
      >
        <thead className="table-light">
          <tr>
            <th scope="col">Movie Name</th>
            <th scope="col">Actor Name</th>
            <th scope="col">Release Date</th>
            <th scope="col">Movie Type</th>
          </tr>
        </thead>
        <tbody id="table-body">
          {props.movies?.map((mov) => (
            <tr key={mov.movieName}>
              <td>{mov.movieName}</td>
              <td>{mov.actorName}</td>
              <td>{mov.releaseDate}</td>
              <td>{mov.movieType?.join(",")}</td>
            </tr>
          ))}
          {props.movies?.length === 0 && (
            <tr>
                <td colSpan="4" className="text-center text-muted fst-italic py-3">No movies added yet.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}