import Main from "./components/Main";
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css'
export default function App(){
  return <div><Main/></div>
}