import { useContext, useState } from "react";
import { UserContext } from "./UserContext";

export default function FruitForm() {
  const [fruitName, setFruitName] = useState("");
  const [error, setError] = useState("");
  const context = useContext(UserContext);

  const handleSubmit = () => {
    const { error: newError } = context.addFruitsToList(fruitName);
    if (newError) {
      setError(newError);
    } else {
      setError("");
      setFruitName("");
    }
  };

  return (
    <div className="mb-4 p-3 border rounded shadow-sm bg-light">
      <div className="input-group">
        <input
          type="text"
          className="form-control"
          name="fruitName"
          value={fruitName}
          onChange={(e) => {
            setFruitName(e.target.value);
            // Clear error on new typing
            if (error) setError("");
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleSubmit();
          }}
          placeholder="Enter fruit name (e.g., Apple)..."
        />

        <button className="btn btn-primary" onClick={handleSubmit}>
          <i className="bi bi-plus-circle-fill me-2"></i>
          Add Fruit
        </button>
      </div>

      {error && (
        <div className="alert alert-danger mt-3 p-2" role="alert">
          <i className="bi bi-exclamation-triangle-fill me-2"></i>
          {error}
        </div>
      )}
    </div>
  );
}
