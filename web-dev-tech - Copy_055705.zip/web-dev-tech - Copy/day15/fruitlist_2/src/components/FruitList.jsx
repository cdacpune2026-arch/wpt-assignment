import { useContext } from "react";
import { UserContext } from "./UserContext";

export default function FruitList() {
  const context = useContext(UserContext);
  const fruits = context.fruits || [];

  return (
    <div>
      <h2 className="mb-3 text-secondary">Current Fruits ({fruits.length})</h2>

      {/* Conditional rendering for an empty list */}
      {fruits.length === 0 ? (
        <div className="alert alert-info">
          The fruit list is currently empty.
        </div>
      ) : (
        /* Applied Bootstrap table classes */
        <table className="table table-hover table-bordered shadow-sm">
          <thead>
            <tr className="table-primary">
              <th scope="col">Fruit Name</th>
              <th scope="col" className="text-center">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {fruits.map((fruit, index) => (
              <tr key={index}>
                <td>{fruit}</td>
                <td className="text-center">
                  <button
                    className="btn btn-sm btn-outline-danger" // Small button with danger outline
                    title={`Delete ${fruit}`}
                    onClick={() => context.deleteFruit(fruit)}
                  >
                    <i className="bi bi-trash-fill" /> {/* Filled trash icon */}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
