import { useState } from "react";
import { UserContext } from "./UserContext";
import FruitForm from "./FruitForm";
import FruitList from "./FruitList";

export default function Main() {
  const [fruits, setFruits] = useState([]);

  const addFruitsToList = function (fruitName) {
    const trimmedFruitName = fruitName.trim();
    if (!trimmedFruitName) {
      return { error: "Fruit name cannot be empty" };
    }
    if (fruits.find((fruit) => fruit === trimmedFruitName)) {
      return { error: "Fruit already in the list" };
    }

    setFruits([...fruits, trimmedFruitName]);
    return { msg: "success" };
  };

  const deleteFruit = (name) => {
    setFruits(fruits.filter((fruit) => fruit != name));
  };

  return (
    <UserContext.Provider value={{ fruits, addFruitsToList, deleteFruit }}>
      <div className="container py-5">
        <h1 className="text-center mb-4">Fruit List Manager</h1>
        <div className="row justify-content-center">
          <div className="col-md-6">
            <FruitForm />
            <FruitList />
          </div>
        </div>
      </div>
    </UserContext.Provider>
  );
}
