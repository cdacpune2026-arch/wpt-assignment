import { createContext } from "react";

export const UserContext = createContext({ fruits: [], setFruits: () => {} });
