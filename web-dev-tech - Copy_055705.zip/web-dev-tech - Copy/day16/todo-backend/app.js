const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
const router = require("./routers/todoRouter");

const app = express();

const corsOptions = {
  origin: "http://localhost:5173", // Only allow this frontend
  methods: "GET,POST", // Only allow these HTTP methods
  allowedHeaders: "Content-Type,Authorization", // Only allow these headers
};

app.use(cors(corsOptions));

app.use(express.urlencoded());
app.use(express.json());

app.use(morgan("short"));

app.use("/todos", router);

app.get("/", (req, res) => {
  res.send("HEALTHY");
});
app.listen("8081", (err) => {
  if (err) {
    console.error(err);
    return;
  }

  console.log("Server started successfully on: ", "8081");
});
