const todos = [];

exports.addTodoTask = function (req, res) {
  const { body } = req;

  const { task, expiry = "N/A" } = body;

  if (!task || String(task).length == 0) {
    res.status(400);
    res.json({ error: "task cant be empty" });
    return;
  }

  if (todos.find((todo) => todo.task == task)) {
    res.status(400);
    res.json({ error: "task already exists" });
    return;
  }
  todos.push({
    task,
    taskId: todos.length + 1,
    expiry: expiry.length == 0 ? "N/A" : expiry,
  });

  res.json({ msg: "task added successfully", taskId: todos.length });
};

exports.getTodos = function (req, res) {
  res.json({ todos });
};

exports.updateTodoStatus = function (req, res) {
  const {
    body: { taskId, task, status = "complete" },
  } = req;

  if (!taskId && !task) {
    res.status(400);
    res.json({ error: "Either taskId or task is required" });
    return;
  }

  let todoToUpdate = todos.find(
    (todo) => todo.taskId == taskId || todo.task == task
  );

  if (!todoToUpdate) {
    res.status(400);
    res.json({ error: "No such task" });
    return;
  }

  todos.forEach((todo) => {
    if (todo.taskId == taskId || todo.task == task) {
      todo.status = status;
    }
  });

  res.json({
    msg: "status updated",
    ...(taskId ? { taskId } : { task }),
    status,
  });
};
