const express = require("express");
const { addTodoTask, getTodos, updateTodoStatus } = require("../controllers/todoController");
const router = express.Router();

router.post("/new", addTodoTask)
router.get("/", getTodos)
router.post("/update_status", updateTodoStatus)

module.exports = router;