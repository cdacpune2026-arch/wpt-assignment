import Main from "./components/Main";

export default function App(){
  return <div>
    <Main/>
  </div>
}