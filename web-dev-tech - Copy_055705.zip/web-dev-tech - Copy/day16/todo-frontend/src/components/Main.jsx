import { useEffect, useState } from "react";
import TodoForm from "./todo-form/TodoForm";
import TodoList from "./todo-list/TodoList";
import "./Main.css";

export default function Main() {
  const [todos, setTodos] = useState([]);

  const fetchTodos = () => {
    fetch("http://localhost:8081/todos", {
      method: "GET",
    })
      .then((res) => res.json())
      .then((data) => {
        setTodos(data.todos);
      })
      .catch((err) => alert(err));
  };

  const updateTaskStatus = (taskIdentifier, status) => {
    console.log("todos:::", todos);
    setTodos((prev) =>
      prev.map((todo) => {
        if (
          (todo.taskId && todo.taskId === taskIdentifier.taskId) ||
          todo.task === taskIdentifier.task
        ) {
          return { ...todo, status };
        }

        return todo;
      })
    );
  };

  useEffect(() => {
    fetchTodos();
  }, []);

  return (
    <div className="main-container">
      <TodoForm setTodos={setTodos} />
      <TodoList todos={todos} updateTaskStatus={updateTaskStatus} />
    </div>
  );
}
