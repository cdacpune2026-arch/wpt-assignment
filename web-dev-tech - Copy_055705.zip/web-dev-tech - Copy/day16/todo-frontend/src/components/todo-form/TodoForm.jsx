import { useState } from "react";
import "./TodoForm.css";

export default function TodoForm(props) {
  const [error, setError] = useState("");
  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    const formData = new FormData(form);

    try {
      const res = await fetch("http://localhost:8081/todos/new", {
        method: "POST",
        body: JSON.stringify(Object.fromEntries(formData.entries())),
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await res.json();

      if (data.error) {
        setError(data.error);
        return;
      } else {
        if (error) {
          setError("");
        }
      }

      form.reset();
      props.setTodos((prev) => [
        ...prev,
        {
          ...Object.fromEntries(formData.entries()),
          expiry: formData.get("expiry") ? formData.get("expiry") : "N/A",
        },
      ]);
    } catch (err) {
      alert(err);
    }
  };

  return (
    <div className="todo-form-container">
      <form className="todo-form" onSubmit={handleFormSubmit}>
        <input
          type="text"
          required
          name="task"
          placeholder="Enter task..."
          onChange={() => {
            if (error) setError("");
          }}
        />
        <label>
          Expiry date:
          <input
            type="date"
            name="expiry"
            onChange={() => {
              if (error) setError("");
            }}
          />
        </label>
        <button>Add</button>
      </form>

      {error ? <div className="form-error">{error}</div> : null}
    </div>
  );
}
