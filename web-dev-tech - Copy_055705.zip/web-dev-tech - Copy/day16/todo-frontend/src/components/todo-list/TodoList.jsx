import "./TodoList.css"

export default function TodoList(props) {
  const updateTaskStatus = async (taskIdentifier, taskStatus) => {
    try {
      const res = await fetch("http://localhost:8081/todos/update_status", {
        method: "POST",
        body: JSON.stringify({ ...taskIdentifier, status: taskStatus }),
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await res.json();

      if (data.error) {
        alert(data.error);
        return;
      }

      props.updateTaskStatus(taskIdentifier, taskStatus);
    } catch (err) {
      alert(err);
    }
  };
  return (
    <div>
      <table className="todo-list-table">
        <thead>
          <tr>
            <th>Task</th>
            <th>Expiry</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {props.todos.map((todo) => (
            <tr key={todo.taskId || todo.task}>
              <td>{todo.task}</td>
              <td>{todo.expiry}</td>
              <td>
                <div className="task-actions">
                  <button
                    className="complete-btn"
                    onClick={() => {
                      const taskIdentifier = {};
                      if (todo.taskId) {
                        taskIdentifier.taskId = todo.taskId;
                      } else {
                        taskIdentifier.task = todo.task;
                      }

                      updateTaskStatus(taskIdentifier, "complete");
                    }}
                    disabled={todo.status == "complete"}
                  >
                    Complete
                  </button>
                  <button
                    className="reject-btn"
                    onClick={() => {
                      const taskIdentifier = {};
                      if (todo.taskId) {
                        taskIdentifier.taskId = todo.taskId;
                      } else {
                        taskIdentifier.task = todo.task;
                      }

                      updateTaskStatus(taskIdentifier, "reject");
                    }}
                    disabled={todo.status == "reject"}
                  >
                    Reject
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
