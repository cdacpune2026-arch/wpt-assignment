import Timer from "./components/Timer";
import "./App.css"

export default function App() {
  return (
    <div className="main">
      <div className="main-header">Hello</div>
      <Timer />
    </div>
  );
}
