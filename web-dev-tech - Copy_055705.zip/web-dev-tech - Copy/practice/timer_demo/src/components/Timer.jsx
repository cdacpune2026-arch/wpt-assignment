import { useEffect, useState } from "react";
import "./Timer.css";

let timerInterval;
export default function Timer() {
  const [timer, setTimer] = useState(10);
  const [disableResend, setDisableResend] = useState(false);

  const handleResend = () => {
    setDisableResend(true);
    new Promise((resolve) => {
      setTimeout(resolve, 2000);
    }).then(() => {
      setDisableResend(false);
      setTimer(10);
    });
  };

  useEffect(() => {
    if (timerInterval) {
      if (timer == 0) {
        clearInterval(timerInterval);
        timerInterval = undefined;
      }
    } else {
      timerInterval = setInterval(() => setTimer((prev) => prev - 1), 1000);
    }
  }, [timer]);
  return (
    <div className="timer-container">
      <div className="timer-text">
        Resend Available {timer != 0 ? "in" : "now"}:
      </div>
      <div className="variable-content-wrapper">
        {timer !== 0 ? (
          <div className="timer-countdown">{timer}</div>
        ) : (
          <button
            disabled={disableResend}
            onClick={handleResend}
            className="resend-button"
          >
            Resend email
          </button>
        )}
      </div>
    </div>
  );
}
